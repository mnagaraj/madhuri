The latest changes :

mysql_connect.php : Contains the code for connecting to the remote MySQL database.

getInfo.php/index.php : This is the actual php file where the data is read from the database. For now, I am just reading the company
ID and its respective name. The query for actual search will be updated.

readJson.html : This is just a test file. It contains html and some Javascript code. This file reads the json data 
from the server(index.php).

